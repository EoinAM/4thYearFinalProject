/********************************************************************************
** Form generated from reading UI file 'newtilewindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NEWTILEWINDOW_H
#define UI_NEWTILEWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_NewTileWindow
{
public:
    QWidget *centralwidget;
    QWidget *verticalLayoutWidget_2;
    QVBoxLayout *verticalLayout;
    QFormLayout *formLayout;
    QLabel *m_TileImageLabel;
    QLabel *m_SelectFileText;
    QHBoxLayout *horizontalLayout;
    QLabel *m_FileLocationText;
    QPushButton *m_SelectFileButton;
    QSpacerItem *verticalSpacer;
    QLabel *m_InsertTileName;
    QLabel *m_TileTypeText;
    QComboBox *m_TypeSelection;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer;
    QPushButton *m_AddButton;
    QPushButton *m_CancelButton;
    QPlainTextEdit *m_TileNameInput;
    QSpacerItem *verticalSpacer_2;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *NewTileWindow)
    {
        if (NewTileWindow->objectName().isEmpty())
            NewTileWindow->setObjectName(QString::fromUtf8("NewTileWindow"));
        NewTileWindow->resize(800, 527);
        centralwidget = new QWidget(NewTileWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        verticalLayoutWidget_2 = new QWidget(centralwidget);
        verticalLayoutWidget_2->setObjectName(QString::fromUtf8("verticalLayoutWidget_2"));
        verticalLayoutWidget_2->setGeometry(QRect(20, 20, 769, 451));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget_2);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setSizeConstraint(QLayout::SetNoConstraint);
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        formLayout = new QFormLayout();
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        formLayout->setSizeConstraint(QLayout::SetNoConstraint);
        m_TileImageLabel = new QLabel(verticalLayoutWidget_2);
        m_TileImageLabel->setObjectName(QString::fromUtf8("m_TileImageLabel"));
        m_TileImageLabel->setAlignment(Qt::AlignCenter);

        formLayout->setWidget(0, QFormLayout::FieldRole, m_TileImageLabel);

        m_SelectFileText = new QLabel(verticalLayoutWidget_2);
        m_SelectFileText->setObjectName(QString::fromUtf8("m_SelectFileText"));
        m_SelectFileText->setEnabled(true);
        QFont font;
        font.setPointSize(15);
        m_SelectFileText->setFont(font);

        formLayout->setWidget(1, QFormLayout::LabelRole, m_SelectFileText);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        m_FileLocationText = new QLabel(verticalLayoutWidget_2);
        m_FileLocationText->setObjectName(QString::fromUtf8("m_FileLocationText"));
        QFont font1;
        font1.setPointSize(12);
        m_FileLocationText->setFont(font1);
        m_FileLocationText->setAlignment(Qt::AlignJustify|Qt::AlignVCenter);

        horizontalLayout->addWidget(m_FileLocationText);

        m_SelectFileButton = new QPushButton(verticalLayoutWidget_2);
        m_SelectFileButton->setObjectName(QString::fromUtf8("m_SelectFileButton"));
        m_SelectFileButton->setFont(font1);

        horizontalLayout->addWidget(m_SelectFileButton);


        formLayout->setLayout(1, QFormLayout::FieldRole, horizontalLayout);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        formLayout->setItem(2, QFormLayout::FieldRole, verticalSpacer);

        m_InsertTileName = new QLabel(verticalLayoutWidget_2);
        m_InsertTileName->setObjectName(QString::fromUtf8("m_InsertTileName"));
        m_InsertTileName->setFont(font);

        formLayout->setWidget(3, QFormLayout::LabelRole, m_InsertTileName);

        m_TileTypeText = new QLabel(verticalLayoutWidget_2);
        m_TileTypeText->setObjectName(QString::fromUtf8("m_TileTypeText"));
        m_TileTypeText->setFont(font);

        formLayout->setWidget(5, QFormLayout::LabelRole, m_TileTypeText);

        m_TypeSelection = new QComboBox(verticalLayoutWidget_2);
        m_TypeSelection->addItem(QString());
        m_TypeSelection->addItem(QString());
        m_TypeSelection->addItem(QString());
        m_TypeSelection->setObjectName(QString::fromUtf8("m_TypeSelection"));
        m_TypeSelection->setEditable(false);

        formLayout->setWidget(5, QFormLayout::FieldRole, m_TypeSelection);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setSizeConstraint(QLayout::SetNoConstraint);
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        m_AddButton = new QPushButton(verticalLayoutWidget_2);
        m_AddButton->setObjectName(QString::fromUtf8("m_AddButton"));
        m_AddButton->setFont(font1);

        horizontalLayout_2->addWidget(m_AddButton);

        m_CancelButton = new QPushButton(verticalLayoutWidget_2);
        m_CancelButton->setObjectName(QString::fromUtf8("m_CancelButton"));
        m_CancelButton->setFont(font1);

        horizontalLayout_2->addWidget(m_CancelButton);


        formLayout->setLayout(6, QFormLayout::FieldRole, horizontalLayout_2);

        m_TileNameInput = new QPlainTextEdit(verticalLayoutWidget_2);
        m_TileNameInput->setObjectName(QString::fromUtf8("m_TileNameInput"));
        m_TileNameInput->setEnabled(true);
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(m_TileNameInput->sizePolicy().hasHeightForWidth());
        m_TileNameInput->setSizePolicy(sizePolicy);
        m_TileNameInput->setFont(font);
        m_TileNameInput->viewport()->setProperty("cursor", QVariant(QCursor(Qt::IBeamCursor)));
        m_TileNameInput->setAcceptDrops(false);
        m_TileNameInput->setToolTipDuration(-1);
        m_TileNameInput->setInputMethodHints(Qt::ImhNone);
        m_TileNameInput->setSizeAdjustPolicy(QAbstractScrollArea::AdjustToContentsOnFirstShow);
        m_TileNameInput->setLineWrapMode(QPlainTextEdit::WidgetWidth);
        m_TileNameInput->setTabStopWidth(25);

        formLayout->setWidget(3, QFormLayout::FieldRole, m_TileNameInput);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        formLayout->setItem(4, QFormLayout::FieldRole, verticalSpacer_2);


        verticalLayout->addLayout(formLayout);

        NewTileWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(NewTileWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 26));
        NewTileWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(NewTileWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        NewTileWindow->setStatusBar(statusbar);

        retranslateUi(NewTileWindow);

        m_TypeSelection->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(NewTileWindow);
    } // setupUi

    void retranslateUi(QMainWindow *NewTileWindow)
    {
        NewTileWindow->setWindowTitle(QApplication::translate("NewTileWindow", "Jigsaw Tiled Map Designer", nullptr));
        m_TileImageLabel->setText(QString());
        m_SelectFileText->setText(QApplication::translate("NewTileWindow", "File Location", nullptr));
        m_FileLocationText->setText(QApplication::translate("NewTileWindow", "File Location", nullptr));
        m_SelectFileButton->setText(QApplication::translate("NewTileWindow", "Select Location", nullptr));
        m_InsertTileName->setText(QApplication::translate("NewTileWindow", "Tile Name", nullptr));
        m_TileTypeText->setText(QApplication::translate("NewTileWindow", "Tile Type", nullptr));
        m_TypeSelection->setItemText(0, QApplication::translate("NewTileWindow", "Floor", nullptr));
        m_TypeSelection->setItemText(1, QApplication::translate("NewTileWindow", "Wall", nullptr));
        m_TypeSelection->setItemText(2, QString());

        m_AddButton->setText(QApplication::translate("NewTileWindow", "Add Tile", nullptr));
        m_CancelButton->setText(QApplication::translate("NewTileWindow", "Cancel", nullptr));
        m_TileNameInput->setPlainText(QString());
        m_TileNameInput->setPlaceholderText(QApplication::translate("NewTileWindow", "Insert New Tile Name", nullptr));
    } // retranslateUi

};

namespace Ui {
    class NewTileWindow: public Ui_NewTileWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NEWTILEWINDOW_H
