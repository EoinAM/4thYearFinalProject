/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_2;
    QGraphicsView *graphicsView;
    QGraphicsView *m_FullCameraView;
    QHBoxLayout *horizontalLayout_3;
    QLabel *m_layerText;
    QComboBox *m_layerCombo;
    QSpacerItem *horizontalSpacer;
    QHBoxLayout *horizontalLayout;
    QTableWidget *Icon_Table;
    QVBoxLayout *verticalLayout;
    QPushButton *m_applyButton;
    QPushButton *m_clearCellButton;
    QPushButton *m_exportButton;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->setWindowModality(Qt::ApplicationModal);
        MainWindow->resize(766, 611);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        verticalLayout_2 = new QVBoxLayout(centralwidget);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        graphicsView = new QGraphicsView(centralwidget);
        graphicsView->setObjectName(QString::fromUtf8("graphicsView"));
        graphicsView->setMaximumSize(QSize(10000, 16777215));
        graphicsView->setAcceptDrops(true);

        horizontalLayout_2->addWidget(graphicsView);

        m_FullCameraView = new QGraphicsView(centralwidget);
        m_FullCameraView->setObjectName(QString::fromUtf8("m_FullCameraView"));

        horizontalLayout_2->addWidget(m_FullCameraView);

        horizontalLayout_2->setStretch(0, 1);
        horizontalLayout_2->setStretch(1, 1);

        verticalLayout_2->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        m_layerText = new QLabel(centralwidget);
        m_layerText->setObjectName(QString::fromUtf8("m_layerText"));
        QFont font;
        font.setPointSize(11);
        m_layerText->setFont(font);

        horizontalLayout_3->addWidget(m_layerText);

        m_layerCombo = new QComboBox(centralwidget);
        m_layerCombo->addItem(QString());
        m_layerCombo->addItem(QString());
        m_layerCombo->setObjectName(QString::fromUtf8("m_layerCombo"));

        horizontalLayout_3->addWidget(m_layerCombo);

        horizontalSpacer = new QSpacerItem(100, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer);

        horizontalLayout_3->setStretch(0, 1);
        horizontalLayout_3->setStretch(1, 1);
        horizontalLayout_3->setStretch(2, 1);

        verticalLayout_2->addLayout(horizontalLayout_3);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        Icon_Table = new QTableWidget(centralwidget);
        if (Icon_Table->columnCount() < 10)
            Icon_Table->setColumnCount(10);
        if (Icon_Table->rowCount() < 2)
            Icon_Table->setRowCount(2);
        Icon_Table->setObjectName(QString::fromUtf8("Icon_Table"));
        Icon_Table->setRowCount(2);
        Icon_Table->setColumnCount(10);
        Icon_Table->horizontalHeader()->setVisible(false);
        Icon_Table->horizontalHeader()->setMinimumSectionSize(50);
        Icon_Table->horizontalHeader()->setDefaultSectionSize(50);
        Icon_Table->horizontalHeader()->setHighlightSections(false);
        Icon_Table->verticalHeader()->setVisible(false);
        Icon_Table->verticalHeader()->setMinimumSectionSize(50);
        Icon_Table->verticalHeader()->setDefaultSectionSize(50);
        Icon_Table->verticalHeader()->setHighlightSections(false);

        horizontalLayout->addWidget(Icon_Table);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        m_applyButton = new QPushButton(centralwidget);
        m_applyButton->setObjectName(QString::fromUtf8("m_applyButton"));
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(m_applyButton->sizePolicy().hasHeightForWidth());
        m_applyButton->setSizePolicy(sizePolicy);

        verticalLayout->addWidget(m_applyButton);

        m_clearCellButton = new QPushButton(centralwidget);
        m_clearCellButton->setObjectName(QString::fromUtf8("m_clearCellButton"));
        sizePolicy.setHeightForWidth(m_clearCellButton->sizePolicy().hasHeightForWidth());
        m_clearCellButton->setSizePolicy(sizePolicy);

        verticalLayout->addWidget(m_clearCellButton);

        m_exportButton = new QPushButton(centralwidget);
        m_exportButton->setObjectName(QString::fromUtf8("m_exportButton"));

        verticalLayout->addWidget(m_exportButton);


        horizontalLayout->addLayout(verticalLayout);


        verticalLayout_2->addLayout(horizontalLayout);

        verticalLayout_2->setStretch(0, 2);
        verticalLayout_2->setStretch(2, 1);
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 766, 20));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Jigsaw Tiled Map Designer", nullptr));
        m_layerText->setText(QApplication::translate("MainWindow", "Choose A Tile Layer To Work On ", nullptr));
        m_layerCombo->setItemText(0, QApplication::translate("MainWindow", "Floor Layer", nullptr));
        m_layerCombo->setItemText(1, QApplication::translate("MainWindow", "Node Layer", nullptr));

        m_applyButton->setText(QApplication::translate("MainWindow", "Apply Selected Texture", nullptr));
        m_clearCellButton->setText(QApplication::translate("MainWindow", "Clear Selected Cells", nullptr));
        m_exportButton->setText(QApplication::translate("MainWindow", "Export Map", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
