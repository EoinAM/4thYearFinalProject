/********************************************************************************
** Form generated from reading UI file 'maplayoutscreen.ui'
**
** Created by: Qt User Interface Compiler version 5.12.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAPLAYOUTSCREEN_H
#define UI_MAPLAYOUTSCREEN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MapLayoutScreen
{
public:
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout_3;
    QLabel *m_LayoutNewMapText;
    QFormLayout *formLayout;
    QSpinBox *m_WidthValue;
    QLabel *m_GridHeightValue;
    QSpinBox *m_HeightValue;
    QPushButton *m_createButton;
    QPushButton *m_cancelButton;
    QLabel *m_GridWidthValue;
    QStatusBar *statusbar;
    QMenuBar *menubar;

    void setupUi(QMainWindow *MapLayoutScreen)
    {
        if (MapLayoutScreen->objectName().isEmpty())
            MapLayoutScreen->setObjectName(QString::fromUtf8("MapLayoutScreen"));
        MapLayoutScreen->resize(616, 321);
        centralwidget = new QWidget(MapLayoutScreen);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        verticalLayout_3 = new QVBoxLayout(centralwidget);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        m_LayoutNewMapText = new QLabel(centralwidget);
        m_LayoutNewMapText->setObjectName(QString::fromUtf8("m_LayoutNewMapText"));
        QFont font;
        font.setPointSize(35);
        m_LayoutNewMapText->setFont(font);
        m_LayoutNewMapText->setAlignment(Qt::AlignCenter);

        verticalLayout_3->addWidget(m_LayoutNewMapText);

        formLayout = new QFormLayout();
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        formLayout->setFieldGrowthPolicy(QFormLayout::ExpandingFieldsGrow);
        formLayout->setLabelAlignment(Qt::AlignCenter);
        formLayout->setFormAlignment(Qt::AlignCenter);
        m_WidthValue = new QSpinBox(centralwidget);
        m_WidthValue->setObjectName(QString::fromUtf8("m_WidthValue"));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(1);
        sizePolicy.setHeightForWidth(m_WidthValue->sizePolicy().hasHeightForWidth());
        m_WidthValue->setSizePolicy(sizePolicy);
        QFont font1;
        font1.setPointSize(15);
        m_WidthValue->setFont(font1);
        m_WidthValue->setAcceptDrops(false);
        m_WidthValue->setMinimum(1);
        m_WidthValue->setValue(10);

        formLayout->setWidget(0, QFormLayout::FieldRole, m_WidthValue);

        m_GridHeightValue = new QLabel(centralwidget);
        m_GridHeightValue->setObjectName(QString::fromUtf8("m_GridHeightValue"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(m_GridHeightValue->sizePolicy().hasHeightForWidth());
        m_GridHeightValue->setSizePolicy(sizePolicy1);
        m_GridHeightValue->setFont(font1);
        m_GridHeightValue->setFrameShape(QFrame::NoFrame);
        m_GridHeightValue->setFrameShadow(QFrame::Plain);
        m_GridHeightValue->setTextFormat(Qt::PlainText);
        m_GridHeightValue->setScaledContents(false);
        m_GridHeightValue->setAlignment(Qt::AlignCenter);

        formLayout->setWidget(1, QFormLayout::LabelRole, m_GridHeightValue);

        m_HeightValue = new QSpinBox(centralwidget);
        m_HeightValue->setObjectName(QString::fromUtf8("m_HeightValue"));
        QSizePolicy sizePolicy2(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(1);
        sizePolicy2.setVerticalStretch(1);
        sizePolicy2.setHeightForWidth(m_HeightValue->sizePolicy().hasHeightForWidth());
        m_HeightValue->setSizePolicy(sizePolicy2);
        m_HeightValue->setFont(font1);
        m_HeightValue->setMinimum(1);
        m_HeightValue->setValue(10);

        formLayout->setWidget(1, QFormLayout::FieldRole, m_HeightValue);

        m_createButton = new QPushButton(centralwidget);
        m_createButton->setObjectName(QString::fromUtf8("m_createButton"));
        m_createButton->setFont(font1);

        formLayout->setWidget(2, QFormLayout::LabelRole, m_createButton);

        m_cancelButton = new QPushButton(centralwidget);
        m_cancelButton->setObjectName(QString::fromUtf8("m_cancelButton"));
        m_cancelButton->setFont(font1);

        formLayout->setWidget(2, QFormLayout::FieldRole, m_cancelButton);

        m_GridWidthValue = new QLabel(centralwidget);
        m_GridWidthValue->setObjectName(QString::fromUtf8("m_GridWidthValue"));
        m_GridWidthValue->setFont(font1);
        m_GridWidthValue->setAlignment(Qt::AlignCenter);

        formLayout->setWidget(0, QFormLayout::LabelRole, m_GridWidthValue);


        verticalLayout_3->addLayout(formLayout);

        MapLayoutScreen->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(MapLayoutScreen);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MapLayoutScreen->setStatusBar(statusbar);
        menubar = new QMenuBar(MapLayoutScreen);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 616, 20));
        MapLayoutScreen->setMenuBar(menubar);

        retranslateUi(MapLayoutScreen);

        QMetaObject::connectSlotsByName(MapLayoutScreen);
    } // setupUi

    void retranslateUi(QMainWindow *MapLayoutScreen)
    {
        MapLayoutScreen->setWindowTitle(QApplication::translate("MapLayoutScreen", "Jigsaw Tiled Map Designer", nullptr));
        m_LayoutNewMapText->setText(QApplication::translate("MapLayoutScreen", "Select New Map Values", nullptr));
        m_GridHeightValue->setText(QApplication::translate("MapLayoutScreen", "Map Height", nullptr));
        m_createButton->setText(QApplication::translate("MapLayoutScreen", "Create Map", nullptr));
        m_cancelButton->setText(QApplication::translate("MapLayoutScreen", "Cancel", nullptr));
        m_GridWidthValue->setText(QApplication::translate("MapLayoutScreen", "Map Width", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MapLayoutScreen: public Ui_MapLayoutScreen {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAPLAYOUTSCREEN_H
