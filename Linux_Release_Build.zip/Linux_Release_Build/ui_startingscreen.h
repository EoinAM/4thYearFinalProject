/********************************************************************************
** Form generated from reading UI file 'startingscreen.ui'
**
** Created by: Qt User Interface Compiler version 5.12.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STARTINGSCREEN_H
#define UI_STARTINGSCREEN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_StartingScreen
{
public:
    QWidget *centralwidget;
    QLabel *m_TitleLabel;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QPushButton *m_NewLevelBut;
    QSpacerItem *verticalSpacer_2;
    QPushButton *m_LoadLevelButton;
    QSpacerItem *verticalSpacer;
    QPushButton *m_quitButton;
    QLabel *label;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *StartingScreen)
    {
        if (StartingScreen->objectName().isEmpty())
            StartingScreen->setObjectName(QString::fromUtf8("StartingScreen"));
        StartingScreen->resize(800, 600);
        centralwidget = new QWidget(StartingScreen);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        m_TitleLabel = new QLabel(centralwidget);
        m_TitleLabel->setObjectName(QString::fromUtf8("m_TitleLabel"));
        m_TitleLabel->setGeometry(QRect(50, 0, 771, 81));
        QFont font;
        font.setPointSize(25);
        m_TitleLabel->setFont(font);
        m_TitleLabel->setTextFormat(Qt::AutoText);
        m_TitleLabel->setAlignment(Qt::AlignCenter);
        verticalLayoutWidget = new QWidget(centralwidget);
        verticalLayoutWidget->setObjectName(QString::fromUtf8("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(80, 100, 631, 401));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        m_NewLevelBut = new QPushButton(verticalLayoutWidget);
        m_NewLevelBut->setObjectName(QString::fromUtf8("m_NewLevelBut"));
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(m_NewLevelBut->sizePolicy().hasHeightForWidth());
        m_NewLevelBut->setSizePolicy(sizePolicy);

        verticalLayout->addWidget(m_NewLevelBut);

        verticalSpacer_2 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Preferred);

        verticalLayout->addItem(verticalSpacer_2);

        m_LoadLevelButton = new QPushButton(verticalLayoutWidget);
        m_LoadLevelButton->setObjectName(QString::fromUtf8("m_LoadLevelButton"));
        sizePolicy.setHeightForWidth(m_LoadLevelButton->sizePolicy().hasHeightForWidth());
        m_LoadLevelButton->setSizePolicy(sizePolicy);

        verticalLayout->addWidget(m_LoadLevelButton);

        verticalSpacer = new QSpacerItem(10, 20, QSizePolicy::Minimum, QSizePolicy::Preferred);

        verticalLayout->addItem(verticalSpacer);

        m_quitButton = new QPushButton(verticalLayoutWidget);
        m_quitButton->setObjectName(QString::fromUtf8("m_quitButton"));
        sizePolicy.setHeightForWidth(m_quitButton->sizePolicy().hasHeightForWidth());
        m_quitButton->setSizePolicy(sizePolicy);

        verticalLayout->addWidget(m_quitButton);

        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(110, 0, 91, 81));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy1);
        label->setText(QString::fromUtf8("<html><head/><body><p><img src=\":/Images/Icon.png\" width =\"70\" height = \"70\" /></p></body></html>"));
        StartingScreen->setCentralWidget(centralwidget);
        menubar = new QMenuBar(StartingScreen);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 26));
        StartingScreen->setMenuBar(menubar);
        statusbar = new QStatusBar(StartingScreen);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        StartingScreen->setStatusBar(statusbar);

        retranslateUi(StartingScreen);

        QMetaObject::connectSlotsByName(StartingScreen);
    } // setupUi

    void retranslateUi(QMainWindow *StartingScreen)
    {
        StartingScreen->setWindowTitle(QApplication::translate("StartingScreen", "Jigsaw Tiled Map Designer", nullptr));
        m_TitleLabel->setText(QApplication::translate("StartingScreen", "Jigsaw Tiled Map Designer", nullptr));
        m_NewLevelBut->setText(QApplication::translate("StartingScreen", "Create New Level", nullptr));
        m_LoadLevelButton->setText(QApplication::translate("StartingScreen", "Load Existing Level", nullptr));
        m_quitButton->setText(QApplication::translate("StartingScreen", " Quit", nullptr));
    } // retranslateUi

};

namespace Ui {
    class StartingScreen: public Ui_StartingScreen {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STARTINGSCREEN_H
